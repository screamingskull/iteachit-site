from turtle import *
from random import *
import multiShape

#pen colours must be type FLOAT
penRed = 0.0 
penGreen = 0.0
penBlue = 0.0

#speed 0 is the fastest possible
speed(0)

#User input
sideLength = int(input("Enter side length: "))
numSides = int(input("Enter number of sides: "))
repeat = int(input("Enter number of repeats: "))
turnAngle = int(input("Turn angle between shapes: "))

#Shape drawing routine
for loop in range(0, repeat):
    color(penRed,penGreen,penBlue)
    multiShape.shape(sideLength, numSides) #Draw shape using multishape.shape()
    right(turnAngle)
    
    if penRed < 0.9:
        penRed += 0.1
    elif penBlue < 0.9:
        penBlue += 0.1
    elif penGreen < 0.9:
        penGreen += 0.1
    else:
        penRed = 0.0       
        penGreen = 0.0
        penBlue = 0.0
