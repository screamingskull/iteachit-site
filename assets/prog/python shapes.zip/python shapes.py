from turtle import *
import multiShape

speed(0)
turn = 10

for loop in range(0, int(40)):
    multiShape.shape(200-loop*5,4)
    right(turn)
