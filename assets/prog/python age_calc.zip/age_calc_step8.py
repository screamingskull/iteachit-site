name=input("Please enter your name: ")

age=int(input("Hello, "+name+". How old are you? "))

ageMonths=age * 12
ageDays=age * 365

print("Your age in months is: ")
print(ageMonths)

print("Your age in days is: ")
print(ageDays)
