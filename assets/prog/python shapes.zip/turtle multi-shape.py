from turtle import *
 
def shape(length, sides):
   for shapeLoop in range(0, sides):
      forward(length)
      right(360/sides)

counter = 100
speed(0)

while counter > 0:
   shape(100,3)
   right(5)
   counter -= 1
   
