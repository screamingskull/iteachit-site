from turtle import *

def shape(sideLength, numSides):
    for shapeLoop in range(0, numSides):
        forward(sideLength)
        right(360/numSides)
