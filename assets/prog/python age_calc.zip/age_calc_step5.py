name=input("Please enter your name: ")

age=input("Hello, "+name+". How old are you? ")

ageMonths=age * 12
