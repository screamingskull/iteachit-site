from turtle import *
from random import *
#from winsound import *
import multiShape

colourDict = {1:"red",
              2:"orange",
              3:"yellow",
              4:"green",
              5:"blue",
              6:"purple"}

penColour = 1
speed(0)

#User input
sideLength = int(input("Enter side length: "))
numSides = int(input("Enter number of sides: "))
repeat = int(input("Enter number of repeats: "))
turnAngle = int(input("Turn angle between shapes: "))

#Shape drawing routine
for shapeLoop in range(0, repeat):
    color(colourDict[penColour])
    #Beep(sideLength * (penColour + turnAngle), numSides * 20)
    multiShape.shape(sideLength, numSides) #Draw shape using multishape.shape()
    right(turnAngle)
    
    if penColour < 6:
        penColour += 1
    else:
        penColour = 1       
