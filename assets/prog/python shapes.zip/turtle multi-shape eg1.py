from turtle import *
 
def shape(length, sides):               #Function definition
   for shapeLoop in range(0, sides):    #Iterative loop
      forward(length)
      right(360/sides)

counter = 100
speed(0)

while counter > 0:                      #More iteration using a while loop
   shape(100,3)                         #Function shape in called here
   right(5)
   counter -= 1
