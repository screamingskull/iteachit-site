print("Please enter your name: ")
name=input("")
