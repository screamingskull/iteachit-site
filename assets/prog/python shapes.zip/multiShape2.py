from turtle import *
 
def shape(length, sides):
   for shapeLoop in range(0, sides):
      forward(length)
      right(360/sides)

