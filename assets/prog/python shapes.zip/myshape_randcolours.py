from turtle import *
from random import *
import multiShape

colourDict = {1:"red",
              2:"orange",
              3:"yellow",
              4:"green",
              5:"blue",
              6:"purple"}


speed(0)

#User input
sideLength = int(input("Enter side length: "))
numSides = int(input("Enter number of sides: "))
repeat = int(input("Enter number of repeats: "))
turnAngle = int(input("Turn angle between shapes: "))


#Shape drawing routine
for shapeLoop in range(0, repeat):
    color(colourDict[randint(1,6)])
    multiShape.shape(sideLength, numSides) #Draw shape using multishape.shape()
    right(turnAngle)
    
