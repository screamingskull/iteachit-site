name=input("Please enter your name: ")

age=int(input("Hello, "+name+". How old are you? "))

ageMonths=age * 12

print("Your age in months is: ")
print(ageMonths)
