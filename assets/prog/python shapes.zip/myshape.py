from turtle import *
import multiShape

speed(0) #This make the turtle draw at the fastest possible speed

#User input
sideLength = int(input("Enter side length: "))
numSides = int(input("Enter number of sides: "))
repeat = int(input("Enter number of repeats: "))
turnAngle = int(input("Turn angle between shapes: "))
#

#Shape drawing routine
for shapeLoop in range(0, repeat):
    multiShape.shape(sideLength, numSides) #Draw shape using multishape.shape()
    right(turnAngle)
    
