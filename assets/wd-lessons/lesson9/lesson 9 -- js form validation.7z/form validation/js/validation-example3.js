function formError() {
	var name = document.forms["testForm"]["name"].value;
	var age = document.forms["testForm"]["age"].value;   
}