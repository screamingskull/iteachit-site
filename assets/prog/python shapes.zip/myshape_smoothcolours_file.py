from turtle import *
import multiShape

patternFile = open("pattern.txt", "r")

colourDict = {1:"red",
              2:"orange",
              3:"yellow",
              4:"green",
              5:"blue",
              6:"purple"}

penColour = 1
speed(0)

#File input
while patternFile.readline() != "END":
    sideLength = int(patternFile.readline())
    numSides = int(patternFile.readline())
    repeat = int(patternFile.readline())
    turnAngle = int(patternFile.readline())

    #Shape drawing routine
    for shapeLoop in range(0, repeat):
        color(colourDict[penColour])
        multiShape.shape(sideLength, numSides)
        right(turnAngle)
        
        if penColour < 6:
            penColour += 1
        else:
            penColour = 1       
