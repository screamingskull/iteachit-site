name=input("Please enter your name: ")

age=int(input("Hello, "+name+". How old are you? "))

ageMonths=age * 12
ageDays=age * 365
ageHours=ageDays * 24
ageMinutes=ageHours * 60
ageSeconds = ageMinutes * 60

print("Your age in months is: ")
print(ageMonths)

print("Your age in days is: ")
print(ageDays)

print("Your age in hours is: ")
print(ageHours)

print("Your age in minutes is: ")
print(ageMinutes)

print("Your age in seconds is: ")
print(ageSeconds)
