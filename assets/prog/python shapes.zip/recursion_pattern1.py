import turtle

myTurtle = turtle.Turtle()
myWin = turtle.Screen()

def drawSpiral(myTurtle, steps):
    if steps > 0:
        myTurtle.forward(10)
        myTurtle.right(100-steps)
        drawSpiral(myTurtle,steps-1)

drawSpiral(myTurtle,10)
