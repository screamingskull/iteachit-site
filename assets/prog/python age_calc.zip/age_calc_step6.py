name=input("Please enter your name: ")

age=int(input("Hello, "+name+". How old are you? "))

ageMonths=age * 12
