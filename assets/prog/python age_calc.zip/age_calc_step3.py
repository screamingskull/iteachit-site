name=input("Please enter your name: ")

age=input("How old are you? ")
